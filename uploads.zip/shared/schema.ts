import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const itemStatusEnum = pgEnum("item_status", ["pending", "approved", "claimed"]);
export const claimStatusEnum = pgEnum("claim_status", ["pending", "approved", "rejected"]);
export const categoryEnum = pgEnum("category", [
  "electronics",
  "clothing",
  "books",
  "accessories",
  "keys",
  "water-bottles",
  "sports-equipment",
  "other"
]);

export const items = pgTable("items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: categoryEnum("category").notNull(),
  description: text("description").notNull(),
  locationFound: text("location_found").notNull(),
  dateFound: text("date_found").notNull(),
  status: itemStatusEnum("status").notNull().default("pending"),
  photoUrls: text("photo_urls").array().notNull().default(sql`ARRAY[]::text[]`),
  finderName: text("finder_name").notNull(),
  finderContact: text("finder_contact").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const claims = pgTable("claims", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  itemId: varchar("item_id").notNull().references(() => items.id, { onDelete: "cascade" }),
  claimerName: text("claimer_name").notNull(),
  claimerEmail: text("claimer_email").notNull(),
  claimerPhone: text("claimer_phone").notNull(),
  description: text("description").notNull(),
  status: claimStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const itemsRelations = relations(items, ({ many }) => ({
  claims: many(claims),
}));

export const claimsRelations = relations(claims, ({ one }) => ({
  item: one(items, {
    fields: [claims.itemId],
    references: [items.id],
  }),
}));

export const insertItemSchema = createInsertSchema(items).omit({
  id: true,
  createdAt: true,
  status: true,
});

export const insertClaimSchema = createInsertSchema(claims).omit({
  id: true,
  createdAt: true,
  status: true,
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;
export type InsertClaim = z.infer<typeof insertClaimSchema>;
export type Claim = typeof claims.$inferSelect;

export type ItemWithClaims = Item & {
  claims: Claim[];
};
