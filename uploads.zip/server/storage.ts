import { items, claims, type Item, type InsertItem, type Claim, type InsertClaim, type ItemWithClaims } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Items
  createItem(item: InsertItem): Promise<Item>;
  getItem(id: string): Promise<ItemWithClaims | undefined>;
  getAllItems(): Promise<Item[]>;
  getItems(): Promise<Item[]>;
  getRecentItems(limit: number): Promise<Item[]>;
  updateItemStatus(id: string, status: "pending" | "approved" | "claimed"): Promise<Item | undefined>;
  deleteItem(id: string): Promise<void>;
  
  // Claims
  createClaim(claim: InsertClaim): Promise<Claim>;
  getClaims(): Promise<Claim[]>;
  updateClaimStatus(id: string, status: "pending" | "approved" | "rejected"): Promise<Claim | undefined>;
  
  // Stats
  getStats(): Promise<{ total: number; claimed: number; active: number }>;
}

export class DatabaseStorage implements IStorage {
  async createItem(insertItem: InsertItem): Promise<Item> {
    const [item] = await db
      .insert(items)
      .values(insertItem)
      .returning();
    return item;
  }

  async getItem(id: string): Promise<ItemWithClaims | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    if (!item) return undefined;

    const itemClaims = await db.select().from(claims).where(eq(claims.itemId, id));
    
    return {
      ...item,
      claims: itemClaims,
    };
  }

  async getAllItems(): Promise<Item[]> {
    return await db.select().from(items).orderBy(desc(items.createdAt));
  }

  async getItems(): Promise<Item[]> {
    return await db.select().from(items).where(eq(items.status, "approved")).orderBy(desc(items.createdAt));
  }

  async getRecentItems(limit: number): Promise<Item[]> {
    return await db
      .select()
      .from(items)
      .where(eq(items.status, "approved"))
      .orderBy(desc(items.createdAt))
      .limit(limit);
  }

  async updateItemStatus(id: string, status: "pending" | "approved" | "claimed"): Promise<Item | undefined> {
    const [item] = await db
      .update(items)
      .set({ status })
      .where(eq(items.id, id))
      .returning();
    return item || undefined;
  }

  async deleteItem(id: string): Promise<void> {
    await db.delete(items).where(eq(items.id, id));
  }

  async createClaim(insertClaim: InsertClaim): Promise<Claim> {
    const [claim] = await db
      .insert(claims)
      .values(insertClaim)
      .returning();
    return claim;
  }

  async getClaims(): Promise<Claim[]> {
    return await db.select().from(claims).orderBy(desc(claims.createdAt));
  }

  async updateClaimStatus(id: string, status: "pending" | "approved" | "rejected"): Promise<Claim | undefined> {
    const [claim] = await db
      .update(claims)
      .set({ status })
      .where(eq(claims.id, id))
      .returning();

    if (claim && status === "approved") {
      await this.updateItemStatus(claim.itemId, "claimed");
    }

    return claim || undefined;
  }

  async getStats(): Promise<{ total: number; claimed: number; active: number }> {
    const allItems = await db.select().from(items);
    const total = allItems.length;
    const claimed = allItems.filter(item => item.status === "claimed").length;
    const active = allItems.filter(item => item.status === "approved").length;
    
    return { total, claimed, active };
  }
}

export const storage = new DatabaseStorage();
