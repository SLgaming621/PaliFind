import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Package, ShieldCheck } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 border-b bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link href="/" data-testid="link-home">
            <div className="flex items-center gap-2 hover-elevate rounded-md px-3 py-2 -ml-3">
              <Package className="h-6 w-6 text-primary" />
              <span className="text-lg font-semibold">Pali Find
              </span>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <Link href="/browse" data-testid="link-browse">
              <Button
                variant={location === "/browse" ? "secondary" : "ghost"}
                className="gap-2"
              >
                <Search className="h-4 w-4" />
                <span className="hidden sm:inline">Browse Items</span>
              </Button>
            </Link>
            <Link href="/submit" data-testid="link-submit">
              <Button
                variant={location === "/submit" ? "secondary" : "ghost"}
                className="gap-2"
              >
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">Report Found</span>
              </Button>
            </Link>
            <Link href="/admin" data-testid="link-admin">
              <Button
                variant={location === "/admin" ? "secondary" : "ghost"}
                className="gap-2"
              >
                <ShieldCheck className="h-4 w-4" />
                <span className="hidden sm:inline">Admin</span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
