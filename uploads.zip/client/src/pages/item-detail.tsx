import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Package, MapPin, Calendar, User, Mail, ChevronLeft, ChevronRight } from "lucide-react";
import type { ItemWithClaims } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";
import { ClaimDialog } from "@/components/claim-dialog";

const categoryLabels: Record<string, string> = {
  "electronics": "Electronics",
  "clothing": "Clothing",
  "books": "Books",
  "accessories": "Accessories",
  "keys": "Keys",
  "water-bottles": "Water Bottles",
  "sports-equipment": "Sports Equipment",
  "other": "Other"
};

export default function ItemDetail() {
  const [, params] = useRoute("/item/:id");
  const itemId = params?.id;
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [claimDialogOpen, setClaimDialogOpen] = useState(false);

  const { data: item, isLoading } = useQuery<ItemWithClaims>({
    queryKey: [`/api/items/${itemId}`],
    enabled: !!itemId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-10 w-32 mb-6" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Skeleton className="aspect-video" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-32 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg text-muted-foreground">Item not found</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const photos = item.photoUrls && item.photoUrls.length > 0 ? item.photoUrls : [];

  const nextPhoto = () => {
    if (photos.length > 0) {
      setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
    }
  };

  const prevPhoto = () => {
    if (photos.length > 0) {
      setCurrentPhotoIndex((prev) => (prev - 1 + photos.length) % photos.length);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/browse" data-testid="link-back">
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Browse
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <div className="aspect-video bg-muted relative overflow-hidden rounded-lg">
              {photos.length > 0 ? (
                <>
                  <img
                    src={photos[currentPhotoIndex]}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                  {photos.length > 1 && (
                    <>
                      <Button
                        variant="secondary"
                        size="icon"
                        className="absolute left-2 top-1/2 -translate-y-1/2"
                        onClick={prevPhoto}
                        data-testid="button-prev-photo"
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="secondary"
                        size="icon"
                        className="absolute right-2 top-1/2 -translate-y-1/2"
                        onClick={nextPhoto}
                        data-testid="button-next-photo"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-background/80 px-3 py-1 rounded-full text-sm">
                        {currentPhotoIndex + 1} / {photos.length}
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-24 w-24 text-muted-foreground" />
                </div>
              )}
            </div>

            {photos.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto">
                {photos.map((photo, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentPhotoIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 ${
                      index === currentPhotoIndex ? "border-primary" : "border-transparent"
                    }`}
                    data-testid={`button-thumbnail-${index}`}
                  >
                    <img src={photo} alt={`${item.name} ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <div className="flex items-start justify-between gap-2 mb-4">
              <h1 className="text-3xl font-bold" data-testid="text-item-name">{item.name}</h1>
              <Badge variant="secondary">{categoryLabels[item.category]}</Badge>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Item Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Location Found</p>
                      <p className="font-medium" data-testid="text-location">{item.locationFound}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Calendar className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Date Found</p>
                      <p className="font-medium" data-testid="text-date">{new Date(item.dateFound).toLocaleDateString()}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Description</p>
                    <p className="text-sm" data-testid="text-description">{item.description}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Finder Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium" data-testid="text-finder-name">{item.finderName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm" data-testid="text-finder-contact">{item.finderContact}</span>
                  </div>
                </CardContent>
              </Card>

              {item.status === "approved" && (
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={() => setClaimDialogOpen(true)}
                  data-testid="button-claim-item"
                >
                  Claim This Item
                </Button>
              )}

              {item.status === "claimed" && (
                <Card className="border-primary">
                  <CardContent className="p-4 text-center">
                    <p className="font-medium text-primary">This item has been claimed</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      <ClaimDialog 
        open={claimDialogOpen}
        onOpenChange={setClaimDialogOpen}
        item={item}
      />
    </div>
  );
}
