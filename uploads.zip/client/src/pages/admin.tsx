import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ShieldCheck, CheckCircle, XCircle, Trash2, Eye } from "lucide-react";
import type { Item, Claim, ItemWithClaims } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

const categoryLabels: Record<string, string> = {
  "electronics": "Electronics",
  "clothing": "Clothing",
  "books": "Books",
  "accessories": "Accessories",
  "keys": "Keys",
  "water-bottles": "Water Bottles",
  "sports-equipment": "Sports Equipment",
  "other": "Other"
};

export default function Admin() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: items, isLoading: itemsLoading } = useQuery<Item[]>({
    queryKey: ["/api/items/all"],
  });

  const { data: claims, isLoading: claimsLoading } = useQuery<Claim[]>({
    queryKey: ["/api/claims"],
  });

  const approveItemMutation = useMutation({
    mutationFn: async (itemId: string) => {
      return await apiRequest("PATCH", `/api/items/${itemId}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/items/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Item Approved",
        description: "Item is now visible to users.",
      });
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: async (itemId: string) => {
      return await apiRequest("DELETE", `/api/items/${itemId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/items/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Item Deleted",
        description: "Item has been removed.",
      });
    },
  });

  const updateClaimMutation = useMutation({
    mutationFn: async ({ claimId, status }: { claimId: string; status: string }) => {
      return await apiRequest("PATCH", `/api/claims/${claimId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/claims"] });
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Claim Updated",
        description: "Claim status has been updated.",
      });
    },
  });

  const pendingItems = items?.filter(item => item.status === "pending") || [];
  const approvedItems = items?.filter(item => item.status === "approved") || [];
  const pendingClaims = claims?.filter(claim => claim.status === "pending") || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center gap-2 mb-8">
          <ShieldCheck className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        </div>

        <Tabs defaultValue="pending-items" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pending-items" data-testid="tab-pending-items">
              Pending Items
              {pendingItems.length > 0 && (
                <Badge variant="secondary" className="ml-2">{pendingItems.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="active-items" data-testid="tab-active-items">
              Active Listings
            </TabsTrigger>
            <TabsTrigger value="claims" data-testid="tab-claims">
              Claim Requests
              {pendingClaims.length > 0 && (
                <Badge variant="secondary" className="ml-2">{pendingClaims.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending-items">
            <Card>
              <CardHeader>
                <CardTitle>Pending Items Awaiting Approval</CardTitle>
              </CardHeader>
              <CardContent>
                {itemsLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16" />)}
                  </div>
                ) : pendingItems.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Date Found</TableHead>
                        <TableHead>Finder</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingItems.map((item) => (
                        <TableRow key={item.id} data-testid={`row-pending-item-${item.id}`}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{categoryLabels[item.category]}</Badge>
                          </TableCell>
                          <TableCell>{item.locationFound}</TableCell>
                          <TableCell>{new Date(item.dateFound).toLocaleDateString()}</TableCell>
                          <TableCell>{item.finderName}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setLocation(`/item/${item.id}`)}
                                data-testid={`button-view-${item.id}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => approveItemMutation.mutate(item.id)}
                                disabled={approveItemMutation.isPending}
                                data-testid={`button-approve-${item.id}`}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteItemMutation.mutate(item.id)}
                                disabled={deleteItemMutation.isPending}
                                data-testid={`button-delete-${item.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No pending items</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="active-items">
            <Card>
              <CardHeader>
                <CardTitle>Active Listings</CardTitle>
              </CardHeader>
              <CardContent>
                {itemsLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16" />)}
                  </div>
                ) : approvedItems.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Date Found</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {approvedItems.map((item) => (
                        <TableRow key={item.id} data-testid={`row-active-item-${item.id}`}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{categoryLabels[item.category]}</Badge>
                          </TableCell>
                          <TableCell>{item.locationFound}</TableCell>
                          <TableCell>{new Date(item.dateFound).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge>{item.status}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setLocation(`/item/${item.id}`)}
                                data-testid={`button-view-active-${item.id}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteItemMutation.mutate(item.id)}
                                disabled={deleteItemMutation.isPending}
                                data-testid={`button-delete-active-${item.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No active items</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="claims">
            <Card>
              <CardHeader>
                <CardTitle>Claim Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {claimsLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16" />)}
                  </div>
                ) : claims && claims.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item ID</TableHead>
                        <TableHead>Claimer Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {claims.map((claim) => (
                        <TableRow key={claim.id} data-testid={`row-claim-${claim.id}`}>
                          <TableCell className="font-mono text-sm">{claim.itemId.slice(0, 8)}...</TableCell>
                          <TableCell>{claim.claimerName}</TableCell>
                          <TableCell>{claim.claimerEmail}</TableCell>
                          <TableCell>{claim.claimerPhone}</TableCell>
                          <TableCell>
                            <Badge variant={claim.status === "approved" ? "default" : claim.status === "rejected" ? "destructive" : "secondary"}>
                              {claim.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {claim.status === "pending" && (
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => updateClaimMutation.mutate({ claimId: claim.id, status: "approved" })}
                                  disabled={updateClaimMutation.isPending}
                                  data-testid={`button-approve-claim-${claim.id}`}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => updateClaimMutation.mutate({ claimId: claim.id, status: "rejected" })}
                                  disabled={updateClaimMutation.isPending}
                                  data-testid={`button-reject-claim-${claim.id}`}
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No claim requests</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
