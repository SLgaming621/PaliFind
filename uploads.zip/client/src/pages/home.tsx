import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Search, Package, Clock, CheckCircle2, MapPin, Calendar } from "lucide-react";
import type { Item } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const categoryLabels: Record<string, string> = {
  "electronics": "Electronics",
  "clothing": "Clothing",
  "books": "Books",
  "accessories": "Accessories",
  "keys": "Keys",
  "water-bottles": "Water Bottles",
  "sports-equipment": "Sports Equipment",
  "other": "Other"
};

export default function Home() {
  const { data: stats, isLoading: statsLoading } = useQuery<{
    total: number;
    claimed: number;
    active: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const { data: recentItems, isLoading: itemsLoading } = useQuery<Item[]>({
    queryKey: ["/api/items/recent"],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Palisade Lost and Found</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Have you lost an item? Found something? We're here to help. Browse our database of found items or report a new found item. Be sure to check back daily for new listings.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {statsLoading ? (
            <>
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </>
          ) : (
            <>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Items Found</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold" data-testid="text-total-items">{stats?.total || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Items reported by community</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Items Claimed</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold" data-testid="text-claimed-items">{stats?.claimed || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Successfully reunited</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold" data-testid="text-active-items">{stats?.active || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Available to claim</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <Card className="hover-elevate">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5 text-primary" />
                Search for Your Item
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Browse our database of found items. Use filters to narrow down by category, location, or date.
              </p>
              <Link href="/browse" data-testid="button-search-items">
                <Button className="w-full">Browse All Items</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                Report a Found Item
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Found something? Help us reunite it with its owner by submitting the details and photos.
              </p>
              <Link href="/submit" data-testid="button-report-item">
                <Button className="w-full">Report Found Item</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="text-2xl font-semibold mb-6">Recently Found Items</h2>
          {itemsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <Skeleton className="h-48 rounded-t-lg" />
                  <CardContent className="p-4 space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : recentItems && recentItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentItems.map((item) => (
                <Link key={item.id} href={`/item/${item.id}`} data-testid={`card-item-${item.id}`}>
                  <Card className="hover-elevate h-full">
                    <div className="aspect-video bg-muted relative overflow-hidden rounded-t-lg">
                      {item.photoUrls && item.photoUrls.length > 0 ? (
                        <img
                          src={item.photoUrls[0]}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="h-16 w-16 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-semibold text-lg" data-testid={`text-item-name-${item.id}`}>{item.name}</h3>
                        <Badge variant="secondary">{categoryLabels[item.category]}</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4" />
                          <span>{item.locationFound}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(item.dateFound).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg text-muted-foreground">No items found yet</p>
                <p className="text-sm text-muted-foreground mt-2">Be the first to report a found item!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
